// French
language = {
  is_available: "est disponible",
  click_here: "Download",
  update_now: "Mettre à jour maintenant",
  type_to_search: "Filtrer",
  domoticz_settings_saved: "Paramètres enregistrés",
  theme_settings_saved: "Paramètres du thème enregistrés",
  theme_restored: "Thème réinitialisé",
  allow_new_hardware: "Autoriser l'ajout de matériel pendant 5 min",
  is: "est",
  timedout: "expiré",
  mainmenu: "Menu principal",
  you_have: "Vous avez",
  messages: "message(s)",
  warning: "Attention",
  storage_removed: "Stockage local supprimé",
  clear_localstorage: "Vider le cache du navigateur",
  resetTheme_message: "Voulez-vous réinitialiser le thème ou vider le cache du navigateur ?"
};
