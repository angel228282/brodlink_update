// Polish (Template)
language = {
  is_available: "jest dostepny",
  click_here: "Kliknij, aby pobrać",
  update_now: "Aktualizuj teraz",
  type_to_search: "Szukaj",
  domoticz_settings_saved: "Ustawienia Domoticza zostaly zapisane",
  theme_settings_saved: "Ustawienia wygladu zostaly zapisane",
  theme_restored: "Ustawienia wygladu przywrocone",
  allow_new_hardware: "Zezwól na nowe urzšdzenia przez 5 min.",
  is: "jest",
  timedout: "czas minal",
  mainmenu: "Main menu",
  you_have: "You have",
  messages: "message(s)",
  warning: "Warning",
  storage_removed: "Localstorage removed",
  clear_localstorage: "Clear browser storage",
  resetTheme_message: "Do you want to reset the theme to default settings, or just clear browser storage"
};
